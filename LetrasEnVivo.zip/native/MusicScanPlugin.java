package com.letras.envivo;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

@CapacitorPlugin(
  name = "MusicScan",
  permissions = {
    @Permission(strings = { Manifest.permission.READ_MEDIA_AUDIO }, alias = "audio33"),
    @Permission(strings = { Manifest.permission.READ_EXTERNAL_STORAGE }, alias = "audio32")
  }
)
public class MusicScanPlugin extends Plugin {

  private String permAlias() {
    return Build.VERSION.SDK_INT >= 33 ? "audio33" : "audio32";
  }

  @PluginMethod
  public void scan(PluginCall call) {
    if (getPermissionState(permAlias()) != PermissionState.GRANTED) {
      requestPermissionForAlias(permAlias(), call, "permCallback");
      return;
    }
    doScan(call);
  }

  @PermissionCallback
  private void permCallback(PluginCall call) {
    if (getPermissionState(permAlias()) == PermissionState.GRANTED) {
      doScan(call);
    } else {
      call.reject("permiso");
    }
  }

  private void doScan(PluginCall call) {
    JSArray arr = new JSArray();
    Uri collection;
    if (Build.VERSION.SDK_INT >= 29) {
      collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
    } else {
      collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    }
    String[] proj = new String[] {
      MediaStore.Audio.Media._ID,
      MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.ARTIST,
      MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.DURATION,
      MediaStore.Audio.Media.SIZE,
      MediaStore.Audio.Media.DISPLAY_NAME
    };
    String sel = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " > 30000";
    Cursor c = null;
    try {
      c = getContext().getContentResolver().query(collection, proj, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC");
      if (c != null) {
        int iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
        int iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
        int iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
        int iAl = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
        int iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
        int iS = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE);
        int iN = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
        while (c.moveToNext()) {
          long id = c.getLong(iId);
          JSObject o = new JSObject();
          o.put("id", id);
          o.put("title", c.getString(iT));
          o.put("artist", c.getString(iA));
          o.put("album", c.getString(iAl));
          o.put("duration", c.getLong(iD));
          o.put("size", c.getLong(iS));
          o.put("name", c.getString(iN));
          o.put("uri", ContentUris.withAppendedId(collection, id).toString());
          arr.put(o);
        }
      }
    } catch (Exception e) {
      call.reject("scan: " + e.getMessage());
      return;
    } finally {
      if (c != null) {
        c.close();
      }
    }
    JSObject res = new JSObject();
    res.put("songs", arr);
    call.resolve(res);
  }

  @PluginMethod
  public void saveMedia(PluginCall call) {
    String path = call.getString("path");
    String name = call.getString("name");
    String mime = call.getString("mime");
    if (path == null || name == null || mime == null) {
      call.reject("datos incompletos");
      return;
    }
    if (Build.VERSION.SDK_INT < 29) {
      call.reject("Android antiguo");
      return;
    }
    InputStream in = null;
    OutputStream out = null;
    try {
      if (path.startsWith("file://")) {
        path = path.substring(7);
      }
      File src = new File(path);
      ContentResolver cr = getContext().getContentResolver();
      boolean video = mime.startsWith("video");
      ContentValues v = new ContentValues();
      v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
      v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
      String dir = video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES;
      v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/Letras en Vivo");
      v.put(MediaStore.MediaColumns.IS_PENDING, 1);
      Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
      Uri uri = cr.insert(collection, v);
      if (uri == null) {
        call.reject("no se pudo crear el archivo");
        return;
      }
      in = new FileInputStream(src);
      out = cr.openOutputStream(uri);
      if (out == null) {
        call.reject("no se pudo escribir");
        return;
      }
      byte[] buf = new byte[65536];
      int n;
      while ((n = in.read(buf)) > 0) {
        out.write(buf, 0, n);
      }
      out.flush();
      ContentValues done = new ContentValues();
      done.put(MediaStore.MediaColumns.IS_PENDING, 0);
      cr.update(uri, done, null, null);
      JSObject r = new JSObject();
      r.put("uri", uri.toString());
      call.resolve(r);
    } catch (Exception e) {
      call.reject("saveMedia: " + e.getMessage());
    } finally {
      try {
        if (in != null) in.close();
        if (out != null) out.close();
      } catch (Exception ignored) {
      }
    }
  }
}
