import { MediaSession } from '@jofr/capacitor-media-session';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
window.LV = { MediaSession, LocalNotifications, Filesystem, Directory, Share };
